<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proprietor</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .property-table {
            width: 90%;
            margin: 40px auto;
            border-collapse: collapse;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            background: white;
        }

        .property-table th,
        .property-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
            vertical-align: top;
        }

        .property-table th {
            background-color: #508e0f;
            color: white;
            font-weight: 600;
            font-size: 15px;
            letter-spacing: 0.5px;
        }

        .property-table tr:hover {
            background-color: #f8fafc;
        }

        .property-table td {
            padding: 12px 15px;
            font-size: 14px;
            color: #444;
            line-height: 1.6;
        }

        .text_content h4 {
            font-size: 24px;
            color: #2f855a;
            margin: 40px 0 20px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .data-label {
            color: #666;
            font-weight: 500;
            display: inline-block;
            min-width: 120px;
        }
    </style>
</head>

<body>
    <div class="first_head">
        <marquee behavior="scroll" direction="left" style="color:white;font-family: Franklin Gothic Heavy;">
            "The hands that sow seeds today, feed the world tomorrow. Respect every farmer."
        </marquee>
    </div>

    <header class="second_head">
        <div class="web_name">
            <span class="happy">HAPPY</span>
            <span class="harvesters">HARVESTERS</span>
        </div>
        <ul class="links" style=" gap:40px">
        <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="weather.php">Weather</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
        </ul>
    </header>

    <div class="text_content">
        <center>
            <h4>Property Seller Data</h4>
        </center>
    </div>

    <?php
    require_once('lib/function.php');
    $db = new class_property_function();
    $sellers = $db->get_all_property_sellers();
    ?>

    <table class="property-table">
        <thead>
            <tr>
                <th>Personal Details</Details></th>
                <th>Land Location</th>
                <th>Land Details</th>
                <th>Selling Details</th>
                <th>Date & Time</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($sellers as $seller): ?>
            <tr>
            <td>
    <strong>Name:</strong> <?= htmlspecialchars($seller['full_name']) ?><br>
    <strong>Phone:</strong> <?= htmlspecialchars($seller['phone_number']) ?><br>
    <strong>Email:</strong> <?= htmlspecialchars($seller['email']) ?>
</td>
<td>
<strong>State:</strong> <?= htmlspecialchars($seller['state']) ?><br>
<strong>District:</strong> <?= htmlspecialchars($seller['district']) ?><br>
<strong>Taluka:</strong> <?= htmlspecialchars($seller['taluka']) ?><br>
    <strong>Village:</strong> <?= htmlspecialchars($seller['village']) ?><br>
</td>
<td>
    <strong>Area:</strong> <?= htmlspecialchars($seller['total_area']) ?> acres<br>
    <strong>Type:</strong> <?= htmlspecialchars($seller['land_type']) ?><br>
    <strong>Soil:</strong> <?= htmlspecialchars($seller['soli_type']) ?><br>
    <strong>Water:</strong> <?= htmlspecialchars($seller['water']) ?><br>
    <strong>Nearby Facilities:</strong> <?= htmlspecialchars($seller['facility']) ?>

</td>
<td>

<strong>Price:</strong> <?= htmlspecialchars($seller['price']) ?><br>
    <strong>Documents:</strong> <?= htmlspecialchars($seller['documents']) ?><br>
    <strong>Additional Information:</strong> <?= htmlspecialchars($seller['additional_information']) ?>

</td>
<td>
    <strong>Date:</strong> <?= htmlspecialchars($seller['date']) ?><br>
    <strong>Time:</strong> <?= htmlspecialchars($seller['time']) ?>
</td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<br><br><br>
    <!--Footer section-->
<br><br><br>
<footer class="main-footer">
    <div class="footer-container">
        <div class="footer-section">
            <form class="mail-form">
                <input type="email" placeholder="Enter Email" required>
                <button type="submit">SEND</button>
            </form>
        </div>

        <!-- Explore Links -->
        <div class="footer-section">
            <h4>EXPLORE</h4><br>
            <ul class="footer-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
            </ul>
        </div>

        <!-- Contact Info -->
        <div class="footer-section">
            <h4>CONTACT</h4><br>
            <div class="contact-info">
                <p>+91832985966</p>
                <p>happyharvesters@gmail.com</p>
            </div>
        </div>
    </div>
</footer>
<div class="footer-bottom">
    <center><p>FEEL HAPPY TO VISIT OUR WEBSITE</p></center>
</div>
</body>
</html>
