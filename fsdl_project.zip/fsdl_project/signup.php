<?php
    require_once('lib/function.php');
    $db = new class_functions();

    if(isset($_POST['submit'])) {
        $var_name = $_POST['name'];
        $var_username = $_POST['username'];
        $var_password = $_POST['password'];
        $var_email = $_POST['email'];

        $db->create_user_account($var_name, $var_username, $var_password, $var_email);
        header("Location: index.php");
        exit(); 
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign-up</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background-color: rgb(249, 246, 246);
        }
    </style>
</head>
<body>
<div class="first_head">
  <marquee behavior="scroll" direction="left" style="color:white;font-family: Franklin Gothic Heavy;
;">
    "The hands that sow seeds today, feed the world tomorrow. Respect every farmer."
  </marquee>
</div>

    <header class="second_head">
        <div class="web_name">
            <span class="happy">HAPPY</span>
            <span class="harvesters">HARVESTERS</span>
        </div>
        <ul class="links" style=" gap:40px">
        <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="weather.php">Weather</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
        </ul>
    </header>
        <center>
        <div class="container">
            <div class="login-section">
                <h2>SIGN UP</h2>
                <form action="" method="POST">
                    <input type="text" name="name" placeholder="Name" class="input-box" required>
                    <input type="text" name="username" placeholder="Username" class="input-box" required>
                    <input type="password" name="password" placeholder="Password" class="input-box" required>
                    <input type="email" name="email" placeholder="Email" class="input-box" required>
                    <button type="submit" class="login-btn" name="submit">Sign up</button>
                </form>
            </div>
            <div class="welcome-section">
                <h1>Come join us!</h1>
                <p> We are so excited to have you here. If you haven't already, create an account to get access to exclusive offers, rewards, and discounts.</p>
                <br><p>Already have an account? <a href="login.php" style="text-decoration: none;">Login.</a></p>
            </div>
        </div>
    </center>
</body>
</html>
