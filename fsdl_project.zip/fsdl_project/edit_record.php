<?php


    require_once('lib/function.php');
	 $db = new class_functions();
	 
	  $edit_id = "  ";
		
	      if(isset($_GET['edit_id']))
	{
		$edit_id	        =	$_GET['edit_id'];
		$_SESSION['edit_id']	=	$edit_id;
	}
	 $edit_id= $_SESSION['edit_id'];
	 
	 
		  
         	  if(isset($_POST['submit']))
			  {
				  	   $var_name                          =  $_POST['name'];
					   $var_username                      =  $_POST['username'];
                       $var_password                      =  $_POST['password'];
					   $var_email                         =  $_POST['email'];
						 
	 		  $db->update_user_account($var_name,$var_username,$var_password,$var_email ,$edit_id  );

						 
			  }
			  
			  
		$users_data = array();
        $users_data = $db->get_user_data_from_id($edit_id);
		
		if(!empty($users_data))
		{
			          $res_id			    =	$users_data['id'];
					$res_name  	= 	$users_data['res_name'];
					$res_username	=	$users_data['res_username'];
					$res_password	    =	$users_data['res_password'];
					$res_email	=	$users_data['res_email'];
					$res_date			=	$users_data['res_date'];
					$res_time		    =   $users_data['res_time'];
		


		}
		
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Update Sign Up</title>
<style>
  body {
    background-color: #373740;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  .container {
    max-width: 400px;
    padding: 40px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
	height:400px;
	width:800px;
  }
  h2 {
    text-align: center;
    color: #373740;
    margin-bottom: 30px;
  }
   input[type="text"], input[type="email"], input[type="password"] {
    width: calc(100% - 20px);
    padding: 10px; 
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 14px; 
  }
  input[type="submit"] {
    width: 100%;
    padding: 15px;
    margin-top: 20px;
    background-color: #373740;
    color: #fff;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 18px;
    transition: background-color 0.3s ease;
  }
  input[type="submit"]:hover {
    background-color: #2c2d33;
  }
  .form-group {
    text-align: center;
    margin-top: 20px;
    color: #777;
  }
  .form-group a {
    color: #373740;
    text-decoration: none;
    font-weight: bold;
    transition: color 0.3s ease;
  }
  .form-group a:hover {
    color: #2c2d33;
  }
</style>
</head>
<body>
<div class="container">
  <h2>Upate Sign Up</h2>
  <form action="edit_record.php" method="POST">
    <input type="text" name="name" placeholder="Name" required>
    <input type="email" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="email" name="email" placeholder="Email Address" required>

    <input type="submit" value="Update" name="submit">
  
 
  
  </form>
</div>

</body>
</html>
