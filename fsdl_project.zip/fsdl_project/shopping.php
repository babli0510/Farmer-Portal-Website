<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
    nav {
      display: flex;
      justify-content: center;
      background-color: #508e0f;
      padding: 10px;
    }

    nav a {
      color: black;
      text-decoration: none;
      padding: 10px 20px;
      margin: 0 10px;
      border-radius: 5px;
      background-color: white;
      transition: background-color 0.3s;
    }

    nav a:hover {
      background-color: #f2eaea;
    }

    .product-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      padding: 20px;
    }

    .product-card {
      width: 250px;
      margin: 20px;
      padding: 15px;
      border: 1px solid #ddd;
      border-radius: 5px;
      text-align: center;
    }

    .product-card img {
      max-width: 100%;
      height: auto;
      max-height: 150px; 
    }

    .btn {
      padding: 8px 16px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .btn-buy-now {
      background-color: #2196F3;
      color: #fff;
    }
</style>
</head>
<body>
  <div class="first_head">
    <marquee behavior="scroll" direction="left" style="color:white;font-family: Franklin Gothic Heavy;
  ;">
      "The hands that sow seeds today, feed the world tomorrow. Respect every farmer."
    </marquee>
  </div>
  
      <header class="second_head">
          <div class="web_name">
              <span class="happy">HAPPY</span>
              <span class="harvesters">HARVESTERS</span>
          </div>
          <ul class="links" style=" gap:40px">
          <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="weather.php">Weather</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
          </ul>
      </header><br><br><br>
   
    <!--Shopping section-->

    
      <nav>
        <a href="#" onclick="showCategory('seeds')">Seeds</a>
        <a href="#" onclick="showCategory('pesticides')">Pesticides</a>
        <a href="#" onclick="showCategory('agriculture-implements')">Agriculture Implements</a>
      </nav>
    
      <div class="product-container" id="productContainer">
        <!-- Product details will displayed here  -->
      </div>
    
      <script>
        function showCategory(category) {
          const productContainer = document.getElementById('productContainer');
          productContainer.innerHTML = ""; // Clear existing products
    
          const products = getProductsByCategory(category);
    
          products.forEach(product => {
            const productCard = createProductCard(product);
            productContainer.appendChild(productCard);
          });
        }
    
        function getProductsByCategory(category) {
          
          let products = [];
    
          if (category === 'seeds') {
            products = [
              { name: 'Sunflower Seeds', image: 'Images/sunflowerseeds.jpg', price: '55.00', buyNowLink: 'https://amzn.eu/d/exI6p2Y' },
              { name: 'pumpkin seeds', image: 'Images/Pumpkinseeds.jpg', price: '220.00', buyNowLink: 'https://amzn.eu/d/dN8z8VE' },
              { name: 'drumstick Seeds', image: 'Images/drumstickseeds.jpg', price: '495.00', buyNowLink: 'https://amzn.eu/d/76uDMPE' },
              { name: 'betel seeds', image: 'Images/betelseeds.jpg', price: '149.00', buyNowLink: 'https://amzn.eu/d/dVKzuoE' },
              { name: 'sandalwood seeds', image: 'Images/sandalwoodseeds.jpg', price: '55.00', buyNowLink: 'https://amzn.eu/d/6CbMwey' },
              { name: 'ashwaghandha seeds', image: 'Images/ashwagandhaseeds.jpg', price: '180.00', buyNowLink: 'https://amzn.eu/d/1xzWpEp' },
              { name: 'cashew nut apple seeds', image: 'Images/nutappleseeds.jpg', price: '90.00', buyNowLink: 'https://amzn.eu/d/3JUrNd2' },
              { name: 'chandan seeds', image: 'Images/chandanseeds.jpg', price: '156.00', buyNowLink: 'https://amzn.eu/d/bm3TC86' },
              { name: 'Tomato seeds', image: 'Images/tomatoseeds.jpg', price: '215.00', buyNowLink: 'https://amzn.eu/d/83ZhYvq' },
              { name: 'black turmeric seeds', image: 'Images/blackturmericseeds.jpg', price: '209.00', buyNowLink: 'https://amzn.eu/d/0Z9EGCf' },
              { name: 'neem tree seeds', image: 'Images/neemtreeseeds.jpg', price: '299.00', buyNowLink: 'https://amzn.eu/d/f9QzqNp' },
              { name: 'yellow capsicum seeds', image: 'Images/yellowcapsicumseeds.jpg', price: '399.00', buyNowLink: 'https://amzn.eu/d/8V6ROFL' },
              { name: 'brinajl seeds', image: 'Images/brinjalseeds.jpg', price: '79.00', buyNowLink: 'https://amzn.eu/d/ahJtmV2' },
              { name: 'lotus seeds', image: 'images/lotusseeds.jpg', price: '493.00', buyNowLink: 'https://amzn.eu/d/gnHU8bH' },
              { name: 'palak or spinach seeds', image: 'images/palakseeds.jpg', price: '175.00', buyNowLink: 'https://amzn.eu/d/ghfBsYa' },
    
             
            ];
          } else if (category === 'pesticides') {
            products = [
              { name: 'Neem Oil for plants', image: 'Images/neemoil.jpg', price: '2299.00', buyNowLink: 'https://amzn.eu/d/j5ffHIg' },
              { name: 'Soil Booster', image: 'Images/soilbooster.jpg', price: '999.00', buyNowLink: 'https://amzn.eu/d/fObfh6r' },
              { name: 'Rootmax(for high yield)', image: 'Images/rootmax.jpg', price: '769.00', buyNowLink: 'https://amzn.eu/d/1mmgp5q' },
              { name: 'Humi (root growth/plant growth) ', image: 'Images/humi.jpg', price: '1618.00', buyNowLink: 'https://amzn.eu/d/1lbSoGq' },
              { name: 'Organic humic acid', image: 'Images/humic.jpg', price: '350.00', buyNowLink: 'https://amzn.eu/d/h9obWxY' },
              { name: 'Plantic (all in one)', image: 'Images/plantic.jpg', price: '519.00', buyNowLink: 'https://amzn.eu/d/c3Y4wBh' },
              { name: 'jeevamrut', image: 'Images/jeevamrut.jpg', price: '224.00', buyNowLink: 'https://amzn.eu/d/8fiFePK' },
              { name: 'organic herbiside', image: 'Images/herbiside.jpg', price: '275.00', buyNowLink: 'https://amzn.eu/d/8fiFePK' },
              { name: 'Npk growth fertilizer', image: 'Images/npk.jpg', price: '275.00', buyNowLink: 'https://amzn.eu/d/0goZvVv' },
              { name: 'Greenedge', image: 'Images/greenedge.jpg', price: '749.00', buyNowLink: 'https://amzn.eu/d/3MlMTS2' },
              { name: 'Rhizogreen', image: 'Images/rhizogreen.jpg', price: '680.00', buyNowLink: 'https://amzn.eu/d/9MNgFxu' },
              { name: 'Azogreen', image: 'Images/azogreen.jpg', price: '735.00', buyNowLink: 'https://amzn.eu/d/8T61mZ9' },
              { name: 'Amino', image: 'Images/amino.jpg', price: '899.00', buyNowLink: 'https://amzn.eu/d/0KlMTRG' },
              { name: 'Fish Fertilizer', image: 'images/fishfertilizer.jpg', price: '1375.00', buyNowLink: 'https://amzn.eu/d/90VnhtQ' },
              { name: 'NPK growth booster', image: 'images/thasalt.jpg', price: '740.00', buyNowLink: 'https://amzn.eu/d/akpa09y' },
            ];
          }  else if (category === 'agriculture-implements') {
            products = [
              { name: 'Axe', image: 'Images/axe.jpg', price: '475.00', buyNowLink: 'https://amzn.eu/d/5NNy7El' },
              { name: 'Digging Tool', image: 'Images/diggingtool.jpg', price: '399.00', buyNowLink: 'https://amzn.eu/d/dgbChBC' },
              { name: 'Seeding Tray', image: 'Images/seedingtray.jpg', price: '214.00', buyNowLink: 'https://amzn.eu/d/cgfGV4Z' },
              { name: 'Handel Rake', image: 'Images/handelrake.jpg', price: '902.00', buyNowLink: 'https://amzn.eu/d/1LgU3Uf' },
              { name: 'Sparayer', image: 'Images/sprayer.jpg', price: '2970.00', buyNowLink: 'https://amzn.eu/d/iP84xBv' },
              { name: 'Sprayer pype', image: 'Images/sprayerpype.jpg', price: '686.00', buyNowLink: 'https://amzn.eu/d/44GKlbq' },
              { name: 'Water pumping motor', image: 'Images/motor.jpg', price: '6399.00', buyNowLink: 'https://amzn.eu/d/ccoYPaH' },
              { name: 'Drip', image: 'Images/drip.jpg', price: '389.00', buyNowLink: 'https://amzn.eu/d/dXhK9M9' },
              { name: 'Dripper', image: 'Images/dripper.jpg', price: '2295.00', buyNowLink: 'https://amzn.eu/d/779ZfYP' },
              { name: 'Volve', image: 'Images/volve.jpg', price: '850.00', buyNowLink: 'https://amzn.eu/d/5d9m84Z' },
              { name: 'Mulching Sheet', image: 'Images/mulchingsheet.jpg', price: '499.00', buyNowLink: 'https://amzn.eu/d/6qS2c3i' },
              { name: 'Farming Gloves', image: 'Images/farminggloves.jpg', price: '189.00', buyNowLink: 'https://amzn.eu/d/6HBc6RI' },
              { name: 'Seed Planter', image: 'Images/seedplanter.jpg', price: '810.00', buyNowLink: 'https://amzn.eu/d/1O2qiwh' },
              { name: 'Soil Tester', image: 'images/soiltester.jpg', price: '458.00', buyNowLink: 'https://amzn.eu/d/4AENxFO' },
              { name: 'Led torch', image: 'images/led.jpg', price: '644.00', buyNowLink: 'https://amzn.eu/d/awky4Zr' }, // Add more seed products as needed
            ];
            // Add products for agriculture implements
          }
    
          return products;
        }
    
        function createProductCard(product) {
          const productCard = document.createElement('div');
          productCard.classList.add('product-card');
    
          const productImage = document.createElement('img');
          productImage.src = product.image;
          productCard.appendChild(productImage);
    
          const productName = document.createElement('h3');
          productName.textContent = product.name;
          productCard.appendChild(productName);
    
          const productPrice = document.createElement('p');
          productPrice.textContent = `₹${product.price}`;
          productCard.appendChild(productPrice);
    
          const buyNowButton = createButton('Buy Now', 'btn-buy-now');
          buyNowButton.addEventListener('click', () => buyNow(product));
          productCard.appendChild(buyNowButton);
    
          return productCard;
        }
    
        function createButton(text, className) {
          const button = document.createElement('button');
          button.textContent = text;
          button.classList.add('btn', className);
          return button;
        }
    
        function buyNow(product) {
          // Open the provided link in a new tab/window
          window.open(product.buyNowLink, '_blank');
        }
    
        // Show default category on page load
        showCategory('seeds');
      </script>

    <br><br><br>
    <!--Footer section-->
<br><br><br>
<footer class="main-footer">
    <div class="footer-container">
        <div class="footer-section">
            <form class="mail-form">
                <input type="email" placeholder="Enter Email" required>
                <button type="submit">SEND</button>
            </form>
        </div>

        <!-- Explore Links -->
        <div class="footer-section">
            <h4>EXPLORE</h4><br>
            <ul class="footer-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
            </ul>
        </div>

        <!-- Contact Info -->
        <div class="footer-section">
            <h4>CONTACT</h4><br>
            <div class="contact-info">
                <p>+91832985966</p>
                <p>happyharvesters@gmail.com</p>
            </div>
        </div>
    </div>
</footer>
<div class="footer-bottom">
    <center><p>FEEL HAPPY TO VISIT OUR WEBSITE</p></center>
</div>
</body>
</html>
