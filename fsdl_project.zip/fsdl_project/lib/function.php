<?php

session_start();
   date_default_timezone_set('Asia/kolkata');
   
  class class_functions
		 {
			 private $con;
			 
			 function __construct()
			 {
				 //database connectivity
				 $this->con= new mysqli("localhost","root","","happy_harvesters");
			 }
			 //signup function
			 
			 function create_user_account($name,$username,$password,$email)
			 {
				     $current_date = date("Y-m-d");
					 $current_time = date("H:i:s A");
			 	 
				 if($stmt = $this->con->prepare("INSERT INTO `signup`( `name`, `username`, `password`,`email`,`date`, `time`) VALUES (?,?,?,?,?,?)"))
				 {
					
					 $stmt->bind_param("ssssss",$name,$username,$password,$email,$current_date,$current_time);
					 
					 if($stmt->execute())
					 {
						 return true;
						 
					 }
					 else
					 {
						 return false;
					 }
				 }
			 }

			 //login function
			 function get_user_password($var_username) 
			 {
				if($stmt = $this->con->prepare("SELECT `password` FROM `signup` WHERE `username`=?")) 
				{
					$stmt->bind_param("s", $var_username);
					$stmt->execute();
					$stmt->bind_result($res_password);  // <- should come after execute
					
					if ($stmt->fetch()) {
						return $res_password;
					} else {
						return false;
					}
				}
				return false;
			 }
			 


//get user data

function get_user_data()
{
    if ($stmt = $this->con->prepare("SELECT `id`, `name`,`username`, `password`, `email`, `date`, `time` FROM `signup`"))
		{
        $stmt->bind_result($res_id, $res_name, $res_username, $res_password, $res_email, $res_date, $res_time);

        if ($stmt->execute()) {
            $users_data = array();
            $counter = 0;

            while ($stmt->fetch()) {
                $users_data[$counter]['id'] = $res_id;
                $users_data[$counter]['res_name'] = $res_name;
                $users_data[$counter]['res_username'] = $res_username;
                $users_data[$counter]['res_password'] = $res_password;
                $users_data[$counter]['res_email'] = $res_email;
                $users_data[$counter]['res_date'] = $res_date;
                $users_data[$counter]['res_time'] = $res_time;

                $counter++;
            }

            if (!empty($users_data)) { 
                return $users_data; 
            } else {
                return false;
            }
        }
    }
  }
//delete user record
function delete_users_record($del_id)
  {
	  
	  if($stmt=$this->con->prepare("DELETE FROM `signup`  where `id`=?"))
	  {
		  $stmt->bind_param("i",$del_id);
		  
		  if($stmt->execute())
		  {
			  return true;
		  }
		  else
		  {
			  return false;
		  }
	  }
  }

  //update
  function update_user_account( $var_name ,$var_username,$var_password ,$var_email,$edit_id  )
		
	{
			   $current_date = date("Y-m-d");
		       $current_time = date("H:i:s A");
		
			  if($stmt=$this->con->prepare(" UPDATE `signup` SET `name`=?,`username`=?,`password`=?,`email`=?,`date`=?,`time`=? WHERE `id`=?"))
			  {
				   $stmt->bind_param("ssssssi",$var_name,$var_username,$var_password ,$var_email,$current_date ,$current_time ,$edit_id);
				   
		   if($stmt->execute())
		  {
			  return true;
		  }
		  else
		  {
			  return false;
		  }
		  
		  }

	 }
     //get user data from id 
     function get_user_data_from_id($edit_id)
	 {
		 
		 if($stmt=$this->con->prepare("SELECT `id`, `name`, `username`, `password`, `email`,`date`, `time` FROM `signup` where `id`=? "))
		{
			$stmt->bind_param("i",$edit_id);
			
			$stmt->bind_result($res_id,$res_name,$res_username,$res_password,$res_email,$res_date,$res_time);
			
			if($stmt->execute())
			{
				$users_data = array();
				
				
				if($stmt->fetch())
				{
					$users_data['id']                       =   $res_id;
					$users_data['res_name']            =   $res_name;
					$users_data['res_username']        =   $res_username;
					$users_data['res_password']             =   $res_password;
				    $users_data['res_email']          =   $res_email;
				    $users_data['res_date']	                =	  $res_date;
					$users_data['res_time']                 =	  $res_time;
					
					
				}
				if(!empty($data))
				{
					return $data;
				}
				else
				{
					return false;
				}
				
			}
			
		}
		 
	 }

}//end of the class

//contact function
class class_contact_function
{
    private $con;

    function __construct()
    {
        $this->con = new mysqli("localhost", "root", "", "happy_harvesters");

        if ($this->con->connect_error) {
            die("Connection failed: " . $this->con->connect_error);
        }
    }

    function create_contact_user_account($name, $phone_number, $email, $message)
    {
        $current_date = date("Y-m-d");
        $current_time = date("H:i:s A");

        if ($stmt = $this->con->prepare("INSERT INTO `contact`( `name`, `phone_number`,`email`, `message`, `date`, `time`) VALUES (?,?,?,?,?,?)"))
        {
            $stmt->bind_param("ssssss", $name, $phone_number, $email, $message, $current_date, $current_time);
            return $stmt->execute();
        }
        return false;
    }
}

//agriculturist function

class class_agriculturist_functions
{
    private $con;

    function __construct()
    {
        $this->con = new mysqli("localhost", "root", "", "happy_harvesters");

        if ($this->con->connect_error) {
            die("Connection failed: " . $this->con->connect_error);
        }
    }

    function create_agriculturist_account($var_name, $var_location, $var_specialization, $var_experience, $var_email)
{
    $current_date = date("Y-m-d");
    $current_time = date("H:i:s A");

    // Checking if email already exists
    $check_stmt = $this->con->prepare("SELECT id FROM agriculturist WHERE email = ?");
    $check_stmt->bind_param("s", $var_email);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        return false; // Email already exists return 
    }

    $check_stmt->close();

    if ($stmt = $this->con->prepare("INSERT INTO `agriculturist`(`name`, `location`, `specialization`, `experience`, `email`, `date`, `time`) VALUES (?,?,?,?,?,?,?)"))
    {
        $stmt->bind_param("sssssss", $var_name, $var_location, $var_specialization, $var_experience, $var_email, $current_date, $current_time);
        return $stmt->execute();
    }
    return false;
}
function get_all_agriculturists() 
{
    $result = $this->con->query("SELECT * FROM agriculturist ORDER BY date DESC");
    $agriculturists = array();
    while ($row = $result->fetch_assoc()) 
	{
        $agriculturists[] = $row;
    }
    return $agriculturists;
}
//get user data 
function get_agriculturist_user_data()
{
    if ($stmt = $this->con->prepare("SELECT `id`, `name`, `location`, `specialization`, `experience`, `email`, `date`, `time` FROM `agriculturist`"))
		{
        $stmt->bind_result($res_id, $res_name, $res_location, $res_specialization,$res_experience, $res_email, $res_date, $res_time);

        if ($stmt->execute()) {
            $users_data = array();
            $counter = 0;

            while ($stmt->fetch()) {
                $users_data[$counter]['id'] = $res_id;
                $users_data[$counter]['res_name'] = $res_name;
                $users_data[$counter]['res_location'] = $res_location;
                $users_data[$counter]['res_specialization'] = $res_specialization;
                $users_data[$counter]['res_experience'] = $res_experience;
                $users_data[$counter]['res_email'] = $res_email;
                $users_data[$counter]['res_date'] = $res_date;
                $users_data[$counter]['res_time'] = $res_time;

                $counter++;
            }

            if (!empty($users_data)) { 
                return $users_data; 
            } else {
                return false;
            }
        }
    }
  }
//delete user record
function delete_agriculturist_users_record($del_id)
  {
	  
	  if($stmt=$this->con->prepare("DELETE FROM `agriculturist`  where `id`=?"))
	  {
		  $stmt->bind_param("i",$del_id);
		  
		  if($stmt->execute())
		  {
			  return true;
		  }
		  else
		  {
			  return false;
		  }
	  }
  }
//update
function update_agriculturist_user_account( $var_name , $var_location, $var_specialization, $var_experience, $var_email,$edit_id )
		
{
           $current_date = date("Y-m-d");
           $current_time = date("H:i:s A");
    
          if($stmt=$this->con->prepare(" UPDATE `agriculturist` SET `name`=?,`location`=?,`specialization`=?,`experience`=?,`email`=?,`date`=?,`time`=? WHERE `id`=?"))
          {
               $stmt->bind_param("sssssssi",$var_name,$var_location, $var_specialization, $var_experience, $var_email,$current_date ,$current_time ,$edit_id);
               
       if($stmt->execute())
      {
          return true;
      }
      else
      {
          return false;
      }
      
      }

 }
 //get user data from id 
 function get_agriculturist_user_data_from_id($edit_id)
 {
     
     if($stmt=$this->con->prepare("SELECT `id`, `name`, `location`, `specialization`, `experience`, `email`,`date`, `time` FROM `agriculturist` where `id`=? "))
    {
        $stmt->bind_param("i",$edit_id);
        
        $stmt->bind_result($res_id,$res_name,$res_location,$res_specialization,$res_experience,$res_email,$res_date,$res_time);
        
        if($stmt->execute())
        {
            $users_data = array();
            
            
            if($stmt->fetch())
            {
                $users_data['id']                       =   $res_id;
                $users_data['res_name']                 =   $res_name;
                $users_data['res_location']             =   $res_location;
                $users_data['res_specialization']       =   $res_specialization;
                $users_data['res_experience']           =   $res_experience;
                $users_data['res_email']                =   $res_email;
                $users_data['res_date']	                =	  $res_date;
                $users_data['res_time']                 =	  $res_time;
                
                
            }
            if(!empty($data))
            {
                return $data;
            }
            else
            {
                return false;
            }
            
        }
        
    }
     
 }



}//end of the class

//advocate function
class class_advocate_functions
{
private $con;

function __construct()
{
    $this->con = new mysqli("localhost", "root", "", "happy_harvesters");

    if ($this->con->connect_error) {
        die("Connection failed: " . $this->con->connect_error);
    }
}

function create_advocate_account($var_name, $var_location, $var_specialization, $var_experience, $var_email)
{
$current_date = date("Y-m-d");
$current_time = date("H:i:s A");

// Checking if email already exists
$check_stmt = $this->con->prepare("SELECT id FROM advocate WHERE email = ?");
$check_stmt->bind_param("s", $var_email);
$check_stmt->execute();
$check_stmt->store_result();

if ($check_stmt->num_rows > 0) {
    return false; // Email already exists
}

$check_stmt->close();

if ($stmt = $this->con->prepare("INSERT INTO `advocate`(`name`, `location`, `specialization`, `experience`, `email`, `date`, `time`) VALUES (?,?,?,?,?,?,?)"))
{
    $stmt->bind_param("sssssss", $var_name, $var_location, $var_specialization, $var_experience, $var_email, $current_date, $current_time);
    return $stmt->execute();
}
return false;
}
function get_all_advocate() 
{
$result = $this->con->query("SELECT * FROM advocate ORDER BY date DESC");
$advocate = array();
while ($row = $result->fetch_assoc()) 
{
    $advocate[] = $row;
}
return $advocate;
}

}

//property seller 

class class_property_function
		 {
			 private $con;
			 function __construct()
			 {
				 //database connectivity
				 $this->con= new mysqli("localhost","root","","happy_harvesters");
			 }
			 function create_property_seller_user_account($full_name,$phone_number,$email,$state,$district,$taluka,$village,$total_area,$land_type,$soli_type,$water,$facility,$price,$documents,$additional_information)
			 {
				     $current_date = date("Y-m-d");
					 $current_time = date("H:i:s A");
                     if($stmt = $this->con->prepare("INSERT INTO `property_seller`(`full_name`, `phone_number`,`email`, `state`,`district`,`taluka`,`village`,`total_area`,`land_type`,`soli_type`,`water`,`facility`,`price`,`documents`,`additional_information`, `date`, `time`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"))
                     {
					 $stmt->bind_param("sssssssssssssssss",$full_name,$phone_number,$email,$state,$district,$taluka,$village,$total_area,$land_type,$soli_type,$water,$facility,$price,$documents,$additional_information,$current_date,$current_time);
					 
					 if($stmt->execute())
					 {
						 return true;
						 
					 }
					 else
					 {
						 return false;
					 }
				 }
			 }

             public function get_all_property_sellers()
             {
                 $query = "SELECT * FROM property_seller";
                 $result = $this->con->query($query);
                 if ($result->num_rows > 0) 
                 {
                     return $result->fetch_all(MYSQLI_ASSOC);
                 } else {
                     return array();
                 }
             }

 }
		 
	

?>