<?php

require_once('lib/function.php');
$db = new class_agriculturist_functions();

if (isset($_POST['logout'])) {
    header("location: admin_login.php");
    exit; // Exit after redirection
}

if (isset($_GET['delete_id'])) {
    $del_id = $_GET['delete_id'];
    $db-> delete_agriculturist_users_record($del_id);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #373740;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .module-list {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .module-list li {
            display: inline-block;
            margin-right: 10px;
        }

        .module-list li:last-child {
            margin-right: 0;
        }

        .module-link {
            color: #fff;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .module-link:hover {
            background-color: black;
        }

        .table-container {
            margin: 20px auto;
            width: 80%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
            color: #333;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Signup</h1>
        <form method="post" action="">
            <ul class="module-list">
                <li><a href="report.php" class="module-link">Sign-up</a></li>
                <li><a href="agriculturist_report.php" class="module-link">Agriculturist</a></li>
                <li><input type="submit" value="Log out" name="logout"></li>
            </ul>
        </form>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Sr No</th>
                    <th>Name</th>
                    <th>Location</th>
                    <th>Specialization</th>
                    <th>Experience</th>
                    <th>Email</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $users_data = $db->get_agriculturist_user_data();

                if (!empty($users_data)) {
                    $counter = 0;

                    foreach ($users_data as $record) {
                        $res_id = $users_data[$counter]['id'];
                        $res_name = $users_data[$counter]['res_name'];
                        $res_location = $users_data[$counter]['res_location'];
                        $res_specialization = $users_data[$counter]['res_specialization'];
                        $res_experience = $users_data[$counter]['res_experience'];
                        $res_email = $users_data[$counter]['res_email'];
                        $res_date = $users_data[$counter]['res_date'];
                        $res_time = $users_data[$counter]['res_time'];
                ?>
                        <tr>
                            <td><?php echo $counter + 1; ?></td>
                            <td><?php echo $res_name; ?></td>
                            <td><?php echo $res_location; ?></td>
                            <td><?php echo $res_specialization; ?></td>
                            <td><?php echo $res_experience; ?></td>
                            <td><?php echo $res_email; ?></td>
                            <td><?php echo $res_date; ?></td>
                            <td><?php echo $res_time; ?></td>
                            <td>
                                <a href="edit_agriculturist_record.php?edit_id=<?php echo $res_id; ?>">Edit</a>
                            </td>
                            <td>
                                <a href="agriculturist_report.php?delete_id=<?php echo $res_id; ?>">Delete</a>
                            </td>
                        </tr>
                <?php
                        $counter++;
                    }
                } else {
                    echo "<tr><td colspan='9'>No data found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>

</html>
