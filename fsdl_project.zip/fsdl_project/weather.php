<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/style.css">
  <title>Weather</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to right, #e6f2e6, #f7fff7);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .weather-container {
      max-width: 700px;
      margin: 60px auto;
      background-color: #ffffff;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 100, 0, 0.2);
      padding: 40px;
      text-align: center;
    }

    .weather-container h2 {
      color: #2e7d32;
      font-weight: 600;
    }

    .btn-weather {
      background-color: #4caf50;
      border: none;
      font-size: 18px;
      padding: 10px 25px;
      margin-top: 20px;
    }

    .btn-weather:hover {
      background-color: #388e3c;
    }

    #weather {
      font-size: 18px;
      margin-top: 25px;
      color: #333;
    }
  </style>
</head>

<body>
<div class="first_head">
  <marquee behavior="scroll" direction="left" style="color:white;font-family: Franklin Gothic Heavy;
;">
    "The hands that sow seeds today, feed the world tomorrow. Respect every farmer."
  </marquee>
</div>

    <header class="second_head">
        <div class="web_name">
            <span class="happy">HAPPY</span>
            <span class="harvesters">HARVESTERS</span>
        </div>
        <ul class="links" style=" gap:40px">
        <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="weather.php">Weather</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
        </ul>
    </header><br><br><br>

  <div class="weather-container">
    <h2>🌿 Weather Updates for Farmers</h2>
    <p class="text-muted">Get real-time weather updates to plan your farming efficiently.</p>
    <button class="btn btn-weather" onclick="getLocation()">Get Weather</button>
    <div id="weather"></div>
  </div>

  <script src="home.js"></script>
 <!--Footer section-->
 <br><br><br>
<footer class="main-footer">
    <div class="footer-container">
        <div class="footer-section">
            <form class="mail-form">
                <input type="email" placeholder="Enter Email" required>
                <button type="submit">SEND</button>
            </form>
        </div>

        <!-- Explore Links -->
        <div class="footer-section">
            <h4>EXPLORE</h4><br>
            <ul class="footer-links">
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="services.html">Service</a></li>
                <li><a href="shop.html">Shop</a></li>
                <li><a href="proprietor.html">Proprietor</a></li>
                <li><a href="crop.html">Crop</a></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </div>

        <!-- Contact Info -->
        <div class="footer-section">
            <h4>CONTACT</h4><br>
            <div class="contact-info">
                <p>+91832985966</p>
                <p>happyharvesters@gmail.com</p>
            </div>
        </div>
    </div>
</footer>
<div class="footer-bottom">
    <center><p>FEEL HAPPY TO VISIT OUR WEBSITE</p></center>
</div>
</body>
</html>
