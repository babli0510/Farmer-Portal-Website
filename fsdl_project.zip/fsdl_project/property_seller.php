<?php

require_once('lib/function.php');
$db = new class_property_function();

if (isset($_POST['submit'])) {
    $var_name = $_POST['full_name'];
    $var_phone_number = $_POST['phone_number'];
    $var_email = $_POST['email'];
    $var_state = $_POST['state'];
    $var_district = $_POST['district'];
    $var_taluka = $_POST['taluka'];
    $var_village = $_POST['village'];
    $var_total_area = $_POST['total_area'];
    $var_land_type = $_POST['land_type'];
    $var_soli_type = $_POST['soli_type'];
    $var_water = $_POST['water'];
    $var_facility = $_POST['facility'];
    $var_price = $_POST['price'];
    $var_documents = $_POST['documents'];
    $var_additional_information = $_POST['additional_information'];

    $db->create_property_seller_user_account(
        $var_name,
        $var_phone_number,
        $var_email,
        $var_state,
        $var_district,
        $var_taluka,
        $var_village,
        $var_total_area,
        $var_land_type,
        $var_soli_type,
        $var_water,
        $var_facility,
        $var_price,
        $var_documents,
        $var_additional_information
    );

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Seller</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
      
body {
    font-family: 'Segoe UI', sans-serif;
    background-color: #f1f5f9;
    margin: 0;
    padding: 0;
    color: #333;
}

.property-form {
    max-width: 900px;
    margin: 40px auto;
    background-color: #ffffff;
    padding: 40px;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}

h3.section-title {
    font-size: 20px;
    margin-bottom: 20px;
    color: #2f855a;
    border-bottom: 2px solid #e2e8f0;
    padding-bottom: 10px;
    font-weight: 600;
}

.form-row {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.form-group {
    flex: 1;
    min-width: 240px;
}

input,
select,
textarea {
    width: 100%;
    padding: 12px 16px;
    border: 1.5px solid #cbd5e1;
    border-radius: 10px;
    background-color: #f8fafc;
    font-size: 15px;
    transition: all 0.3s ease;
}

input:focus,
select:focus,
textarea:focus {
    border-color: #38a169;
    background-color: #ffffff;
    outline: none;
    box-shadow: 0 0 0 3px rgba(56, 161, 105, 0.15);
}



.submit-btn {
    background-color: #38a169;
    color: #fff;
    padding: 14px 35px;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.3s ease;
    margin-top: 20px;
}

.submit-btn:hover {
    background-color: #2f855a;
}

/* Responsive */
@media (max-width: 768px) {
    .form-row {
        flex-direction: column;
    }
}
select {
    background-color: #f8fafd; 
    border: 2px solid #5d7605; 
    border-radius: 6px;
    padding: 10px 15px;
    font-size: 16px;
    color: #333;
    width: 100%;
    box-sizing: border-box;
}
.form-row {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
}
.form-row > * {
    flex: 1;
}



    </style>
</head>
<body>
    <div class="first_head">
      <marquee behavior="scroll" direction="left" style="color:white;font-family: Franklin Gothic Heavy;
    ;">
        "The hands that sow seeds today, feed the world tomorrow. Respect every farmer."
      </marquee>
    </div>
    
        <header class="second_head">
            <div class="web_name">
                <span class="happy">HAPPY</span>
                <span class="harvesters">HARVESTERS</span>
            </div>
            <ul class="links" style=" gap:40px">
            <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="weather.php">Weather</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
            </ul>
        </header>
    <br><br><br>
    <center>
        <section class="property-section">
            <h1 style="color:#508e0f;"><strong>PROPERTY SELLER</strong></h1>
            <form class="property-form" action="" method="POST" >
                <!-- Personal Details -->
                <div class="form-section">
                    <h3 class="section-title">Personal Details</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <input type="text" name="full_name" placeholder="Full Name" required>
                        </div>
                        <div class="form-group">
                            <input type="tel" name="phone_number"   placeholder="Contact Number" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="email" name="email"  placeholder="Email Address" required>
                    </div>
                </div>

                <!-- Land Location -->
                <div class="form-section">
                    <h3 class="section-title">Land Location</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <input type="text" name="state" placeholder="State" required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="district" placeholder="District" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <input type="text" name="taluka" placeholder="Taluka/Tehsil" required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="village" placeholder="Village" required>
                        </div>
                    </div>
                </div>

                <!-- Land Details -->
                <div class="form-section">
                    <h3 class="section-title">Land Details</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <input type="number" name="total_area" placeholder="Total Area (in acres)" step="0.01" required>
                        </div>
                        <div class="form-group">
                        <select name="land_type" required>
                            <option value="">Type of Land</option>
                            <option value="Agricultural">Agricultural</option>
                            <option value="Residential">Residential</option>
                            <option value="Commercial">Commercial</option>
                        </select>

                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <input type="text" name="soli_type" placeholder="Soil Type">
                        </div>
                        <div class="form-group">
                        <select name="water" required>
                        <option value="">Water Availability</option>
                        <option value="Year-round">Year-round</option>
                        <option value="Seasonal">Seasonal</option>
                        <option value="Limited">Limited</option>
                        </select>

                        </div>
                    </div>
                    <div class="form-group">
                        <input type="text" name="facility" placeholder="Nearby Facilities (schools, hospitals, etc.)">
                    </div>
                </div>

            

                <!-- Selling Details -->
                <div class="form-section">
                    <h3 class="section-title" style="margin-top:40px;">Selling Details</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <input type="text" name="price" placeholder="Expected Price" required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="documents" placeholder="Available Documents">
                        </div>
                    </div>
                    <div class="form-group">
                        <textarea name="additional_information" placeholder="Additional Information" rows="4"></textarea>
                    </div>
                </div>

                <center>
                <button type="submit" name="submit" class="submit-btn">SUBMIT</button>
                </center>
            </form>
        </section>


        <!--Footer section-->
        <br><br><br>
        <footer class="main-footer">
            <div class="footer-container">
                <div class="footer-section">
                    <form class="mail-form">
                        <input type="email" placeholder="Enter Email" required>
                        <button type="submit">SEND</button>
                    </form>
                </div>

                <!-- Explore Links -->
                <div class="footer-section">
                    <h4>EXPLORE</h4><br>
                    <ul class="footer-links">
                    <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
                    </ul>
                </div>

                <!-- Contact Info -->
                <div class="footer-section">
                    <h4>CONTACT</h4><br>
                    <div class="contact-info">
                        <p>+91832985966</p>
                        <p>happyharvesters@gmail.com</p>
                    </div>
                </div>
            </div>
        </footer>
        <div class="footer-bottom">
            <center>
                <p>FEEL HAPPY TO VISIT OUR WEBSITE</p>
            </center>
        </div>
</body>

</html>