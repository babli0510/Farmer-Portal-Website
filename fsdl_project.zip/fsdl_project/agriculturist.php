<?php
require_once('lib/function.php');
$db = new class_agriculturist_functions();

$message = ""; // Feedback message

if (isset($_POST['submit'])) {
    $var_name = $_POST['name'];
    $var_location = $_POST['location'];
    $var_specialization = $_POST['specialization'];
    $var_experience = $_POST['experience'];
    $var_email = $_POST['email'];

    if ($db->create_agriculturist_account($var_name, $var_location, $var_specialization, $var_experience, $var_email)) {
        $message = "<span style='color: green;'>Agriculturist successfully enrolled!</span>";
    } else {
        $message = "<span style='color: red;'>Email already exists or submission failed. Try again with a different email.</span>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agriculturist</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .property-form {
            max-width: 800px;
            padding: 40px;
            background: #f5f5f5;
            border-radius: 10px;
            margin: 20px auto;
        }

        .form-section {
            margin-bottom: 30px;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-row {
            display: flex;
            gap: 20px;
            margin-bottom: 15px;
        }

        .form-group {
            flex: 1;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #d4d8d6;
            border-radius: 5px;
            margin-top: 5px;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #508e0f;
            outline: none;
        }

        h3.section-title {
            color: #508e0f;
            margin-bottom: 20px;
            border-bottom: 2px solid #d4d8d6;
            padding-bottom: 10px;
        }

        .file-upload {
            border: 2px solid #d4d8d6;
            padding: 20px;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
        }

        .file-upload:hover {
            border-color: #508e0f;
        }

        .submit-btn {
            background-color: #508e0f;
            color: white;
            padding: 15px 40px;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .submit-btn:hover {
            background-color: #3a660b;
        }
        
    /* table  */
    .agriculturist-table-container {
        max-width: 1200px;
        margin: 40px auto;
        padding: 0 20px;
        overflow-x: auto;
    }

    .agriculturist-table {
        width: 100%;
        border-collapse: collapse;
        margin: 25px 0;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    }

    .agriculturist-table th,
    .agriculturist-table td {
        padding: 15px;
        text-align: left;
        border-bottom: 1px solid #d4d8d6;
    }

    .agriculturist-table th {
        background-color: #508e0f;
        color: white;
        font-weight: bold;
    }

    .agriculturist-table tr:nth-child(even) {
        background-color: #f5f5f5;
    }

    .agriculturist-table tr:hover {
        background-color: rgba(80, 142, 15, 0.1);
    }

    @media (max-width: 768px) {
        .agriculturist-table {
            font-size: 14px;
        }
        
        .agriculturist-table th,
        .agriculturist-table td {
            padding: 10px;
        }
    }
    </style>
</head>

<body>
<div class="first_head">
  <marquee behavior="scroll" direction="left" style="color:white;font-family: Franklin Gothic Heavy;
;">
    "The hands that sow seeds today, feed the world tomorrow. Respect every farmer."
  </marquee>
</div>

    <header class="second_head">
        <div class="web_name">
            <span class="happy">HAPPY</span>
            <span class="harvesters">HARVESTERS</span>
        </div>
        <ul class="links" style=" gap:40px">
        <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="weather.php">Weather</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
        </ul>
    </header>
<br><br><br>
 <!--Agriculturist Section--> 
 <section class="contact-section">
    <h3 style="font-size: 30px; color: #508e0f;">Enroll New Agriculturist</h3>
    <div style="max-width: 800px; margin: 0 auto; padding: 20px 0;">
        <?php if (!empty($message)) echo $message; ?><br>
        
    <center>
    <form class="contact-form" action="agriculturist.php" method="POST">
        <input type="text" name="name" placeholder="Your Name" required>
        <input type="text" name="location" placeholder="Location" required>
        <input type="text" name="specialization" placeholder="Specialization" required>
        <input type="tel" name="experience" placeholder="Experience(in years)" required>
        <input type="email" name="email" placeholder="Email" required>
        <button type="submit" name="submit" >Enroll</button>
    </form>
    <!-- Display Agriculturist table -->
    <section class="agriculturist-table-container">
    <?php
    $agriculturists = $db->get_all_agriculturists();
    if (!empty($agriculturists)) {
        echo '
        <table class="agriculturist-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Location</th>
                    <th>Specialization</th>
                    <th>Experience</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>';
        
        foreach ($agriculturists as $agri) {
            echo '
                <tr>
                    <td>'.$agri['name'].'</td>
                    <td>'.$agri['location'].'</td>
                    <td>'.$agri['specialization'].'</td>
                    <td>'.$agri['experience'].' years</td>
                    <td>'.$agri['email'].'</td>
                </tr>';
        }
        
        echo '
            </tbody>
        </table>';
    } else {
        echo '<p style="text-align:center;color:#508e0f;">No agriculturists enrolled yet.</p>';
    }
    ?>
</section>
    </center>
</section>

       <!--Footer section-->
       <br><br><br>
       <footer class="main-footer">
           <div class="footer-container">
               <div class="footer-section">
                   <form class="mail-form">
                       <input type="email" placeholder="Enter Email" required>
                       <button type="submit">SEND</button>
                   </form>
               </div>

               <!-- Explore Links -->
               <div class="footer-section">
                   <h4>EXPLORE</h4><br>
                   <ul class="footer-links">
                   <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
                   </ul>
               </div>

               <!-- Contact Info -->
               <div class="footer-section">
                   <h4>CONTACT</h4><br>
                   <div class="contact-info">
                       <p>+91832985966</p>
                       <p>happyharvesters@gmail.com</p>
                   </div>
               </div>
           </div>
       </footer>
       <div class="footer-bottom">
           <center>
               <p>FEEL HAPPY TO VISIT OUR WEBSITE</p>
           </center>
       </div>
</body>
</html>
