<?php

    require_once('lib/function.php');
	 $db = new class_functions();
	 

	  	  if(isset($_POST['submit']))
			  {
					   $var_username                      =  $_POST['username'];
                       $var_password                      =  $_POST['password'];

						 $db_password = $db->get_user_password($var_username);
						 
						 if($db_password=="")
						 {
								      echo '<script>alert("No registration");</script>';
						 }
						 else
						 {
							 if($var_password==$db_password)
							 {
								//echo "login done" ;
								$_SESSION['login_username'] = $var_username;
								header("location:index.php");
							 }
							 else
							 {
								 
								        echo '<script>alert("Invalid username or password.");</script>';

							 }
						 }
						 
			  }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login </title>
    <link rel="stylesheet" href="css/style.css">
<style>
body
{
    background-color: rgb(244, 239, 239);
}

</style>
</head>
<body>
<div class="first_head">
  <marquee behavior="scroll" direction="left" style="color:white;font-family: Franklin Gothic Heavy;
;">
    "The hands that sow seeds today, feed the world tomorrow. Respect every farmer."
  </marquee>
</div>

    <header class="second_head">
        <div class="web_name">
            <span class="happy">HAPPY</span>
            <span class="harvesters">HARVESTERS</span>
        </div>
        <ul class="links" style=" gap:40px">
        <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="weather.php">Weather</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
        </ul>
    </header>
    <center>
    <div class="container">
        <div class="login-section">
            <h2>LOG-IN</h2>
            <form action="" method="POST">
                <input type="text" placeholder="Username" name="username" class="input-box" required>
                <input type="password" placeholder="Password" name="password" class="input-box" required>
                <button type="submit" name="submit" class="login-btn">Log in</button>
            </form>
        </div>
        <div class="welcome-section">
            <h1>Welcome back!</h1>
            <p>Welcome back! We are so happy to have you here. It's great to see you again. We hope you had a safe and enjoyable time away.</p>
            <br><p>No account yet? <a href="signup.php" style="text-decoration: none;">Signup</a>.</p>
        </div>
    </div>
    </center>
</body>
</html>
