<?php
//  username and password
$valid_username = "02040811";
$valid_password = "project";

$error_message = ""; // Variable to store error message
$success_message = ""; // Variable to store success message

// Check if form is submitted
if (isset($_POST['submit_button'])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if ($username === $valid_username && $password === $valid_password) {
        // Set success message
        $success_message = "Login successful.";
    } else {
        // Set error message
        $error_message = "Invalid username or password.";
    }
}

if (!empty($success_message)) {
    // going to report.php after successful login
    header("location: report.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
  body {
    background-color: #373740;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  .container {
    max-width: 400px;
    padding: 40px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }
  h2 {
    text-align: center;
    color: #373740;
    margin-bottom: 30px;
  }
  input[type="text"], input[type="password"] {
    width: calc(100% - 20px);
    padding: 15px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 16px;
  }
  input[type="submit"] {
    width: 100%;
    padding: 15px;
    margin-top: 20px;
    background-color: #373740;
    color: #ffffff;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 18px;
    transition: background-color 0.3s ease;
  }
  input[type="submit"]:hover {
    background-color: #2c2d33;
  }
  .form-group {
    text-align: center;
    margin-top: 20px;
    color: #777;
  }
  .form-group a {
    color: #373740;
    text-decoration: none;
    font-weight: bold;
    transition: color 0.3s ease;
  }
  .form-group a:hover {
    color: #2c2d33;
  }
</style>
</head>
<body>
<div class="container">
  <h2>Admin Login</h2>
  <?php if (!empty($error_message)) : ?>
    <div class="alert alert-danger" role="alert">
      <?php echo $error_message; ?>
    </div>
  <?php endif; ?>
  
  <?php if (!empty($success_message)) : ?>
    <div class="alert alert-success" role="alert">
      <?php echo $success_message; ?>
    </div>
  <?php endif; ?>
  
  <form action="admin_login.php" method="POST">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="submit" value="Login" name="submit_button">
  </form>
</div>
</body>
</html>
