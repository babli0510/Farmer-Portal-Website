<?php

require_once('lib/function.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'Exception.php';
require 'PHPMailer.php';
require 'SMTP.php';
//Load Composer's autoloader (created by composer, not included with PHPMailer)
//require 'vendor/autoload.php';

$db = new class_contact_function();

if (isset($_POST['submit'])) {
    $var_name = $_POST['name'];
    $var_phone_number = $_POST['phone_number'];
    $var_email = $_POST['email'];
    $var_message = $_POST['message'];
    $db->create_contact_user_account($var_name, $var_phone_number, $var_email, $var_message);

    //Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);

    try {
        //Server settings
        // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication

        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->Username   = 'shraddhagolekar05@gmail.com';                     //SMTP username
        $mail->Password   = 'zebo gaeb yznd bzvu';                               //SMTP password

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;            //Enable implicit TLS encryption
        $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom('shraddhagolekar05@gmail.com', 'shraddha');
        $mail->addAddress('shraddhagolekar05@gmail.com', 'shraddha');     //Add a recipient

        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'New enquiry - happy harvester contact form';
        $mail->Body    = '<h3>Hello you got a new enquiry</h3>
        
        <h4>Name: '.$var_name.'</h4>
        <h4>Phone Number: '.$var_phone_number.' </h4>
        <h4>Email: '.$var_email.'</h4>
        <h4>Message: '.$var_message.'</h4>';

        if ($mail->send()) {
            $_SESSION['status'] = "Thank you for contacting us- Team happy harvesters";
            header("location:{$_SERVER['HTTP_REFERER']}");
            exit();
        } else {
            $_SESSION['status'] = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            header("location:{$_SERVER['HTTP_REFERER']}");
            exit();
        }

    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact-us</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="first_head">
  <marquee behavior="scroll" direction="left" style="color:white;font-family: Franklin Gothic Heavy;
;">
    "The hands that sow seeds today, feed the world tomorrow. Respect every farmer."
  </marquee>
</div>

    <header class="second_head">
        <div class="web_name">
            <span class="happy">HAPPY</span>
            <span class="harvesters">HARVESTERS</span>
        </div>
        <ul class="links" style=" gap:40px">
        <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="weather.php">Weather</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
        </ul>
    </header>
<br><br><br>
    <br><br>
    <!--Contact Section--> 
    <section class="contact-section">
        <h3>OUR CONTACT</h3>
        <h1>REQUEST A CALL BACK</h1>
        <center>
        <form class="contact-form" action="contact.php" method="POST">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="tel" name="phone_number" placeholder="Phone Number" required>
            <input type="text" name="email" placeholder="Email" required>
            <textarea placeholder="Message" name="message" rows="4" required></textarea>
            <button type="submit" name="submit" >SEND</button>
        </form>
        </center>
    </section>
     <!--Footer section-->
<br><br><br>
<footer class="main-footer">
    <div class="footer-container">
        <div class="footer-section">
            <form class="mail-form">
                <input type="email" placeholder="Enter Email" required>
                <button type="submit">SEND</button>
            </form>
        </div>

        <!-- Explore Links -->
        <div class="footer-section">
            <h4>EXPLORE</h4><br>
            <ul class="footer-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
            </ul>
        </div>

        <!-- Contact Info -->
        <div class="footer-section">
            <h4>CONTACT</h4><br>
            <div class="contact-info">
                <p>+91832985966</p>
                <p>happyharvesters@gmail.com</p>
            </div>
        </div>
    </div>
</footer>
<div class="footer-bottom">
    <center><p>FEEL HAPPY TO VISIT OUR WEBSITE</p></center>
</div>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>

    var messageText="<?=$_SESSION['status']?? ''; ?>";
    if(messageText != '')
{

Swal.fire({
  title: "Thank you",
  text: messageText,
  icon: "sucsess"
});
<?php unset($_SESSION['status']); ?>

}
</script>
</body>
</html>
