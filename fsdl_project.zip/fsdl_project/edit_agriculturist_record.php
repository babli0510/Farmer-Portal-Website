<?php


    require_once('lib/function.php');
	 $db = new  class_agriculturist_functions();
	 
	  $edit_id = "  ";
		
	      if(isset($_GET['edit_id']))
	{
		$edit_id	        =	$_GET['edit_id'];
		$_SESSION['edit_id']	=	$edit_id;
	}
	 $edit_id= $_SESSION['edit_id'];
	 
		  
         	  if(isset($_POST['submit']))
			  {
				  	   
                            $var_name = $_POST['name'];
                            $var_location = $_POST['location'];
                            $var_specialization = $_POST['specialization'];
                            $var_experience = $_POST['experience'];
                            $var_email = $_POST['email'];
						 
	 		  $db->update_agriculturist_user_account($var_name,$var_location,$var_specialization,$var_experience,$var_email ,$edit_id  );

						 
			  }
			  
			  
		$users_data = array();
        $users_data = $db->get_agriculturist_user_data_from_id($edit_id);
		
		if(!empty($users_data))
		{
			    $res_id			              =	$users_data['id'];
					$res_name               	= $users_data['res_name'];
					$res_location	            =	$users_data['res_location'];
					$res_specialization	      =	$users_data['res_specialization'];
          $res_experience           = $users_data['res_experience'];
					$res_email	              =	$users_data['res_email'];
					$res_date			            =	$users_data['res_date'];
					$res_time		              =   $users_data['res_time'];
		


		}
		
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Update Agriculturist</title>
<style>
  body {
    background-color: #373740;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  .container {
    max-width: 400px;
    padding: 40px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
	height:420px;
	width:800px;
  }
  h2 {
    text-align: center;
    color: #373740;
    margin-bottom: 30px;
  }
  input[type="text"], 
input[type="email"], 
input[type="password"], 
input[type="tel"] {
  width: calc(100% - 20px);
  padding: 10px;
  margin: 10px 0;
  border: 1px solid #ccc;
  border-radius: 8px;
  box-sizing: border-box;
  font-size: 14px;
}

button[type="submit"] {
  width: 30%;
  padding: 15px;
  margin-top: 20px;
  background-color: #373740;
  color: #fff;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 18px;
  transition: background-color 0.3s ease;
}

button[type="submit"]:hover {
  background-color: #2c2d33;
}
  .form-group {
    text-align: center;
    margin-top: 20px;
    color: #777;
  }
  .form-group a {
    color: #373740;
    text-decoration: none;
    font-weight: bold;
    transition: color 0.3s ease;
  }
  .form-group a:hover {
    color: #2c2d33;
  }
</style>
</head>
<body>
<div class="container">
  <h2>Upate Agriculturist Data </h2>
  <form  action="edit_agriculturist_record.php" method="POST">
        <input type="text" name="name" placeholder="Your Name" required>
        <input type="text" name="location" placeholder="Location" required>
        <input type="text" name="specialization" placeholder="Specialization" required>
        <input type="tel" name="experience" placeholder="Experience(in years)" required>
        <input type="email" name="email" placeholder="Email" required>
        <center>
        <button type="submit" name="submit" >Update</button>
</center>
  
  </form>
</div>

</body>
</html>
