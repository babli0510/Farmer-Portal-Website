<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Youtube</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="first_head">
      <marquee behavior="scroll" direction="left" style="color:white;font-family: Franklin Gothic Heavy;">
        "The hands that sow seeds today, feed the world tomorrow. Respect every farmer."
      </marquee>
    </div>
    
        <header class="second_head">
            <div class="web_name">
                <span class="happy">HAPPY</span>
                <span class="harvesters">HARVESTERS</span>
            </div>
            <ul class="links" style=" gap:40px">
            <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="weather.php">Weather</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
            </ul>
        </header>
    <br><br><br>
<!--Youtube section-->
<br><br>
<section>
<b><center><span style="font-size:25px; color:#4e7421;" >CROP MANAGEMENT</center></span></b><br>
<div class="video-container">
   <div class="resource" >
        <span style="font-size:20px; color:#6e896b;">WHEAT MANAGEMENT</span>
        <br><br><br>
<iframe width="300" height="200" src="https://www.youtube.com/embed/_ULc_pkwMPA" frameborder="0" allowfullscreen></iframe>
   </div>
   <div class="resource">
        <span style="font-size:20px; color:#6e896b;">RICE MANAGEMENT</span>
        <br><br><br>
       <iframe width="300" height="200" src="https://www.youtube.com/embed/FW_bw9jdrlQ" frameborder="0" allowfullscreen></iframe>
       
   </div>
   <div class="resource">
        <span style="font-size:20px; color:#6e896b;">CORN MANAGEMENT</span>
             <br><br><br>
<iframe width="300" height="200" src="https://www.youtube.com/embed/nfMLKP1nXK0" frameborder="0" allowfullscreen></iframe>
   </div>
   <div class="resource">
     <span style="font-size:20px; color:#6e896b;">BARLEY MANAGEMENT</span>
<br><br><br>               
<iframe width="300" height="200" src="https://www.youtube.com/embed/RVYj53ERuUg" frameborder="0" allowfullscreen></iframe>
   </div>
   <div class="resource">
       <span style="font-size:20px; color:#6e896b;">MILLET MANAGEMENT</span>
<br><br><br>   
<iframe width="300" height="200" src="https://www.youtube.com/embed/7WGCIguKYCU" frameborder="0" allowfullscreen></iframe>
   </div>
   <div class="resource">
                       <span style="font-size:20px; color:#6e896b;">SORGHUM MANAGEMENT</span>
<br><br><br>   
       <iframe width="300" height="200" src="https://www.youtube.com/embed/M2srxu_LSBA" frameborder="0" allowfullscreen></iframe>
   </div>
</div>
</section><br><br>

<section>
<b><center><span style="font-size:25px; color:#4e7421;" >PEST AND DISEASES MANAGEMENT</center></span></b><br>
<div class="video-container">
   <div class="resource" >
        <span style="font-size:20px; color:#6e896b;">GRAPES</span>
        <br><br><br>
<iframe width="300" height="200" src="https://www.youtube.com/embed/FSYb2q8FZE0" frameborder="0" allowfullscreen></iframe>
   </div>
   <div class="resource">
        <span style="font-size:20px; color:#6e896b;">COTTON</span>
        <br><br><br>
       <iframe width="300" height="200" src="https://www.youtube.com/embed/arWJqKZ-5vY" frameborder="0" allowfullscreen></iframe>
       
   </div>
   <div class="resource">
        <span style="font-size:20px; color:#6e896b;">CUCUMBER</span>
             <br><br><br>
<iframe width="300" height="200" src="https://www.youtube.com/embed/XgC474Y-Pxc" frameborder="0" allowfullscreen></iframe>
   </div>
   <div class="resource">
     <span style="font-size:20px; color:#6e896b;">MANGO</span>
<br><br><br>               
<iframe width="300" height="200" src="https://www.youtube.com/embed/RD8PO4x8dfY" frameborder="0" allowfullscreen></iframe>
   </div>
   <div class="resource">
       <span style="font-size:20px; color:#6e896b;">BRINGAL</span>
<br><br><br>   
<iframe width="300" height="200" src="https://www.youtube.com/embed/xlAiecrEuo0" frameborder="0" allowfullscreen></iframe>
   </div>
   <div class="resource">
                       <span style="font-size:20px; color:#6e896b;">ONION</span>
<br><br><br>   
       <iframe width="300" height="200" src="https://www.youtube.com/embed/MI3v_k_KeYI" frameborder="0" allowfullscreen></iframe>
   </div>
</div>
</section><br><br>

<section>
<b><center><span style="font-size:25px; color:#4e7421;" >WATER MANAGEMENT AND IRRIGATION</center></span></b><br>
<div class="video-container">
   <div class="resource" >
        <span style="font-size:20px; color:#6e896b;">WATER MANAGEMENT </span>
        <br><br><br>
<iframe width="300" height="200" src="https://www.youtube.com/embed/Ru9rTrTz97s" frameborder="0" allowfullscreen></iframe>
   </div>
   <div class="resource">
        <span style="font-size:20px; color:#6e896b;">WATER AUTOMATION</span>
        <br><br><br>
       <iframe width="300" height="200" src="https://www.youtube.com/embed/PNosxX-1xWM" frameborder="0" allowfullscreen></iframe>
       
   </div>
   <div class="resource">
        <span style="font-size:20px; color:#6e896b;">IRRIGATION TECHNOLOGY</span>
             <br><br><br>
<iframe width="300" height="200" src="https://www.youtube.com/embed/Gz3cR13CIsI" frameborder="0" allowfullscreen></iframe>
   </div>
   
   
  
</div>
</section>

     <!--Footer section-->
<br><br><br>
<footer class="main-footer">
    <div class="footer-container">
        <div class="footer-section">
            <form class="mail-form">
                <input type="email" placeholder="Enter Email" required>
                <button type="submit">SEND</button>
            </form>
        </div>

        <!-- Explore Links -->
        <div class="footer-section">
            <h4>EXPLORE</h4><br>
            <ul class="footer-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
            </ul>
        </div>

        <!-- Contact Info -->
        <div class="footer-section">
            <h4>CONTACT</h4><br>
            <div class="contact-info">
                <p>+91832985966</p>
                <p>happyharvesters@gmail.com</p>
            </div>
        </div>
    </div>
</footer>
<div class="footer-bottom">
    <center><p>FEEL HAPPY TO VISIT OUR WEBSITE</p></center>
</div>
</body>
</html>
