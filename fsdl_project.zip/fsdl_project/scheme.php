<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scheme</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="first_head">
      <marquee behavior="scroll" direction="left" style="color:white;font-family: Franklin Gothic Heavy;
    ;">
        "The hands that sow seeds today, feed the world tomorrow. Respect every farmer."
      </marquee>
    </div>
    
        <header class="second_head">
            <div class="web_name">
                <span class="happy">HAPPY</span>
                <span class="harvesters">HARVESTERS</span>
            </div>
            <ul class="links" style=" gap:40px">
            <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Service</a></li>
            <li><a href="proprietor.php">Proprietor</a></li>
            <li><a href="advocate.php">Advocator</a></li>
            <li><a href="agriculturist.php">Agriculturist</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="weather.php">Weather</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="login"><a href="login.php">LOGIN</a></li>
            </ul>
        </header>
    <br><br><br>

    <section>
        <b><center><span style="font-size:35px; color:#4e7421;" >PDF RESOURCE</center></span></b><br>
        <div class="pdf-container">
            <div class="resource">
                <b><h3 style="font-size:25px;">PDF</h3><br></b>
                <img src="images/pdf.png" style="width: 100%;" alt="PDF Icon"><br><br>
                <a href="https://www.manage.gov.in/publications/farmerbook.pdf"style="font-size:30px;">Download PDF</a>
            </div>
            <div class="resource">
               <h3 style="font-size:25px;">PDF</h3><br>
                <img src="images/pdf.png" style="width: 100%;" alt="PDF Icon"><br><br>
                <a href="https://www.researchgate.net/publication/330683906_Indian_Agriculture_and_Farmers-Problems_and_Reforms"style="font-size:30px;">Download PDF</a>
            </div>
            <div class="resource">
                  <h3 style="font-size:25px;">PDF</h3><br>
                <img src="images/pdf.png" style="width: 100%;" alt="PDF Icon"><br><br>
                <a href="http://www.sikkimforest.gov.in/soer/Farm%20Resources.pdf" style="font-size:30px;">Download PDF</a>
            </div>
            <div class="resource">
                 <h3 style="font-size:25px;">PDF</h3><br>
                <img src="images/pdf.png" style="width: 100%;" alt="PDF Icon"><br><br>
                <a href="https://www.unishivaji.ac.in/uploads/distedu/2022-2023/SIM/SIM%20Oct%202022%20Exam/M.%20A.%20I%20Econ.%20P%20EO1%20Agricultural%20Econ.%20all.PDF" style="font-size:30px;">Download PDF</a>
            </div>
            <div class="resource">
                 <h3 style="font-size:25px;">PDF </h3><br>
                <img src="images/pdf.png" style="width: 100%;" alt="PDF Icon"><br><br>
                <a href="http://www.sikkimforest.gov.in/soer/Farm%20Resources.pdf" style="font-size:30px;">Download PDF</a>
            </div>
            <div class="resource">
                 <h3 style="font-size:25px;">PDF </h3><br>
                <img src="images/pdf.png" style="width: 100%;" alt="PDF Icon"><br><br>
                <a href="https://www.unishivaji.ac.in/uploads/distedu/2022-2023/SIM/SIM%20Oct%202022%20Exam/M.%20A.%20I%20Econ.%20P%20EO1%20Agricultural%20Econ.%20all.PDF" style="font-size:30px;">Download PDF</a>
            </div>
			 <div class="resource">
                 <h3 style="font-size:25px;">PDF </h3><br>
                <img src="images/pdf.png" style="width: 100%;" alt="PDF Icon"><br><br>
                <a href="https://gr.maharashtra.gov.in/Site/Upload/Government%20Resolutions/Marathi/202206031751077901.pdf" style="font-size:30px;">Download PDF</a>
            </div>
			 <div class="resource">
                 <h3 style="font-size:25px;">PDF </h3><br>
                <img src="images/pdf.png" style="width: 100%;" alt="PDF Icon"><br><br>
                <a href="https://gr.maharashtra.gov.in/Site/Upload/Government%20Resolutions/Marathi/202206031751077901.pdf" style="font-size:30px;">Download PDF</a>
            </div>
			<div class="resource">
                 <h3 style="font-size:25px;">PDF </h3><br>
                <img src="images/pdf.png" style="width: 100%;" alt="PDF Icon"><br><br>
                <a href="		https://www.eximbankindia.in/Assets/Dynamic/PDF/Publication-Resources/Newsletters/105file.pdf
" style="font-size:30px;">Download PDF</a>
            </div>
        </div>
    </section>
    <br><br><br>
    <!--Footer section-->
<br><br><br>
<footer class="main-footer">
    <div class="footer-container">
        <div class="footer-section">
            <form class="mail-form">
                <input type="email" placeholder="Enter Email" required>
                <button type="submit">SEND</button>
            </form>
        </div>

        <!-- Explore Links -->
        <div class="footer-section">
            <h4>EXPLORE</h4><br>
            <ul class="footer-links">
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="services.html">Service</a></li>
                <li><a href="shop.html">Shop</a></li>
                <li><a href="proprietor.html">Proprietor</a></li>
                <li><a href="crop.html">Crop</a></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </div>

        <!-- Contact Info -->
        <div class="footer-section">
            <h4>CONTACT</h4><br>
            <div class="contact-info">
                <p>+91832985966</p>
                <p>happyharvesters@gmail.com</p>
            </div>
        </div>
    </div>
</footer>
<div class="footer-bottom">
    <center><p>FEEL HAPPY TO VISIT OUR WEBSITE</p></center>
</div>
</body>
</html>
