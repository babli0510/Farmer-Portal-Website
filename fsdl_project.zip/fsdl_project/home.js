async function getWeather(latitude, longitude) {
    const apiKey = "5f49bc05f8217b5e9445b15a5d5a3854"; 
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${apiKey}&units=metric`;

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.cod === 200) {
            document.getElementById("weather").innerHTML = `
                <h3 class="text-success">${data.name}, ${data.sys.country}</h3>
                <p class="fs-5s">🌡️ Temperature: <strong>${data.main.temp}°C</strong></p>
                <p class="fs-5s">☁️ Weather: <strong>${data.weather[0].description}</strong></p>
            `;
        } else {
            document.getElementById("weather").innerHTML = `<p class="text-danger">${data.message}</p>`;
        }
    } catch (error) {
        document.getElementById("weather").innerHTML = `<p class="text-danger">Error fetching weather data!</p>`;
        console.error("Fetch error:", error);
    }
}

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            position => {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                getWeather(latitude, longitude);
            },
            error => {
                document.getElementById("weather").innerHTML = `<p class="text-danger">Location access denied!</p>`;
                console.error("Geolocation error:", error);
            }
        );
    } else {
        document.getElementById("weather").innerHTML = `<p class="text-danger">Geolocation is not supported by this browser.</p>`;
    }
}

